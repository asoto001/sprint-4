const btnTheMost = document.querySelector('.theMost-section__button');
const btnDeals = document.querySelector('.deals-section__button');
const btnUbication = document.querySelector('.ubication-modal-container__btn-search');
const modalUbiaction = document.querySelector('.ubication-modal-container');
const ubicationClose = document.getElementById('btnClose');
const productClose = document.querySelector('.product-modal__btn-close')
const btnUbicationSearch = document.querySelector('.navbar-container__btn-ubication')
const productModal = document.querySelector('.product-modal');
const cartModal = document.querySelector('.modal-cart');
const btnCart =document.querySelector('.navbar-container__btn-cart');
cartModal.style.display = 'none'
productModal.style.display = 'none';
modalUbiaction.style.display = 'none';



// btnDeals.addEventListener('click', showModalDeal)
// btnTheMost.addEventListener('clicck', showModalMost)

btnCart.addEventListener('click', () => {
  cartModal.style.display = 'block'
})

btnUbicationSearch.addEventListener('click', (e) => {
    modalUbiaction.style.display = 'block';
})

ubicationClose.addEventListener('click', () => {
    modalUbiaction.style.display = 'none';
})

btnDeals.addEventListener('click', () => {
    productModal.style.display = 'block'
})

productClose.addEventListener('click', () => {
    productModal.style.display = 'none';
})